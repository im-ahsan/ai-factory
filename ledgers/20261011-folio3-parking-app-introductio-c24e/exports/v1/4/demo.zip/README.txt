ai-factory design 20261011-folio3-parking-app-introductio-c24e v1 (eb69f957c48a), approved by Hamza (via web) on 2026-10-11

The design as web pages. Open index.html in a browser and pick a screen; each page is in pages/, and its links and buttons open the other pages. The pages need the network for their styles (Tailwind) and fonts (Google Fonts); they need no server.
approved-demo.html is the demo the lead approved, with every screen as a picture.
