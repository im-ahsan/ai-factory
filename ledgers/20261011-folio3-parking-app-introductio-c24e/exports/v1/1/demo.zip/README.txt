ai-factory design 20261011-folio3-parking-app-introductio-c24e v1 (eb69f957c48a), approved by Hamza (via web) on 2026-10-11

The clickable demo the lead approved. Open index.html in a browser; it needs no server and no network.
