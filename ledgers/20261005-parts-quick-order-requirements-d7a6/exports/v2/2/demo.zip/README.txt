ai-factory design 20261005-parts-quick-order-requirements-d7a6 v2 (cc67a06ccf98), approved by mhamza on 2026-10-05

The clickable demo the lead approved. Open index.html in a browser; it needs no server and no network.
